
Velocity WooCommerce Plugin Installation Documentation

1)	Configuration Requirement: Wordpress site with WooCommerce from 2.2.0 to 2.2.11 version must be installed.

2)	Download velocity WooCommerce Plugin by clicking on Download zip button on the right bottom of this page.

3)  Extract the zip and re-zip the folder 'woocommerce-velocity' (inside the extracted folder). 


4)  Installation of Plugin from Admin Panel:

    i)	Login wordpress admin panel and goto Dashboard plugins option.

    ii)	Top of the plugin list click on “Add New” link. Show “Upload Plugin” then click on upload plugin link

    iii)Show Browse option to select plugin ‘woocommerce-velocity.zip’ zipped file from our system and click on “Install Now” link.

    iv)	After successful upload & installation, show plugin activation link.

    v)	if you want activate plugin immediate click on that link .


5)  Plugin Configuration from Admin Panel After Activation:

    i)	First goto WooCommerce settings option.

    ii)	Select the checkout tab then sea below your installed plugin listed.

    iii)In our installed plugin click on settings of plugin then open velocity
            credential form field.

    iv)	In form of velocity plugin activation check box and test mode checkbox .

    v)	And Must be save two filed "IdentityToken", “WorkFlowId/ServiceId" "ApplicationprofileId" & "MerchantProfileId”  provided by velocity. 

6) We have saved the raw request and response objects in &lt;prefix&gt;_velocity_transaction table.